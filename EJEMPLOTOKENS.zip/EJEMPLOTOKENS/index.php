<?php
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/config.php';

use Abadia\CrudApi\AuthService;

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Authorization, Content-Type');

// Manejar preflight de CORS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$auth = new AuthService();

$auth->validarToken();

// Obtener método y ruta
$metodo = $_SERVER['REQUEST_METHOD'];
$ruta   = $_GET['ruta'] ?? '';

switch ($ruta) {
    case 'productos':
        require_once __DIR__ . '/api/products.php';
        break;

    default:
        http_response_code(404);
        echo json_encode(['error' => 'Ruta no encontrada']);
        break;
}