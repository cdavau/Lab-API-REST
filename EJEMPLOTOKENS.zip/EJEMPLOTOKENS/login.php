<?php
require_once __DIR__ . '/vendor/autoload.php';
require_once __DIR__ . '/config.php';

use Abadia\CrudApi\AuthService;

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$metodo = $_SERVER['REQUEST_METHOD'];
$datos = json_decode(file_get_contents('php://input'), true);

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Error de conexión: ' . $conn->connect_error]);
    exit();
}

$auth = new AuthService();

if ($metodo === 'POST' && isset($datos['action']) && $datos['action'] === 'register') {
    $username = $datos['username'] ?? '';
    $password = $datos['password'] ?? '';

    if (empty($username) || empty($password)) {
        http_response_code(400);
        echo json_encode(['error' => 'Username y password son requeridos']);
        exit();
    }

    $hash = password_hash($password, PASSWORD_BCRYPT);

    $stmt = $conn->prepare('INSERT INTO usuarios (username, password) VALUES (?, ?)');
    $stmt->bind_param('ss', $username, $hash);

    if ($stmt->execute()) {
        http_response_code(201);
        echo json_encode(['mensaje' => 'Usuario registrado correctamente']);
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'Error al registrar usuario']);
    }

} elseif ($metodo === 'POST' && isset($datos['action']) && $datos['action'] === 'login') {
    $username = $datos['username'] ?? '';
    $password = $datos['password'] ?? '';

    if (empty($username) || empty($password)) {
        http_response_code(400);
        echo json_encode(['error' => 'Username y password son requeridos']);
        exit();
    }

    $stmt = $conn->prepare('SELECT password FROM usuarios WHERE username = ?');
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $resultado = $stmt->get_result();

    if ($resultado->num_rows === 0) {
        http_response_code(401);
        echo json_encode(['error' => 'Usuario no encontrado']);
        exit();
    }

    $fila = $resultado->fetch_assoc();

    
    if (password_verify($password, $fila['password'])) {
        $token = $auth->generarToken($username);
        echo json_encode(['token' => $token]);
    } else {
        http_response_code(401);
        echo json_encode(['error' => 'Contraseña incorrecta']);
    }

} else {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
}

$conn->close();