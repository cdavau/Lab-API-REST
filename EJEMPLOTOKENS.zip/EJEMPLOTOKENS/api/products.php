<?php
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Error de conexión: ' . $conn->connect_error]);
    exit();
}

$datos = json_decode(file_get_contents('php://input'), true);
$id    = $_GET['id'] ?? null;

switch ($metodo) {

    case 'GET':
        if ($id) {
            $stmt = $conn->prepare('SELECT * FROM productos WHERE id = ?');
            $stmt->bind_param('i', $id);
            $stmt->execute();
            $resultado = $stmt->get_result();

            if ($resultado->num_rows === 0) {
                http_response_code(404);
                echo json_encode(['error' => 'Producto no encontrado']);
            } else {
                echo json_encode($resultado->fetch_assoc());
            }
        } else {
            $resultado = $conn->query('SELECT * FROM productos');
            $productos = [];
            while ($fila = $resultado->fetch_assoc()) {
                $productos[] = $fila;
            }
            echo json_encode($productos);
        }
        break;

    case 'POST':
        $codigo   = $datos['codigo']   ?? '';
        $producto = $datos['producto'] ?? '';
        $precio   = $datos['precio']   ?? 0;
        $cantidad = $datos['cantidad'] ?? 0;

        if (empty($codigo) || empty($producto)) {
            http_response_code(400);
            echo json_encode(['error' => 'Código y producto son requeridos']);
            exit();
        }

        $stmt = $conn->prepare('INSERT INTO productos (codigo, producto, precio, cantidad) VALUES (?, ?, ?, ?)');
        $stmt->bind_param('ssdi', $codigo, $producto, $precio, $cantidad);

        if ($stmt->execute()) {
            http_response_code(201);
            echo json_encode(['mensaje' => 'Producto creado', 'id' => $conn->insert_id]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Error al crear producto']);
        }
        break;

    case 'PUT':
        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'ID requerido para actualizar']);
            exit();
        }

        $codigo   = $datos['codigo']   ?? '';
        $producto = $datos['producto'] ?? '';
        $precio   = $datos['precio']   ?? 0;
        $cantidad = $datos['cantidad'] ?? 0;

        $stmt = $conn->prepare('UPDATE productos SET codigo=?, producto=?, precio=?, cantidad=? WHERE id=?');
        $stmt->bind_param('ssdii', $codigo, $producto, $precio, $cantidad, $id);

        if ($stmt->execute()) {
            echo json_encode(['mensaje' => 'Producto actualizado']);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Error al actualizar producto']);
        }
        break;

    case 'DELETE':
        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'ID requerido para eliminar']);
            exit();
        }

        $stmt = $conn->prepare('DELETE FROM productos WHERE id = ?');
        $stmt->bind_param('i', $id);

        if ($stmt->execute()) {
            echo json_encode(['mensaje' => 'Producto eliminado']);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Error al eliminar producto']);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Método no permitido']);
        break;
}

$conn->close();