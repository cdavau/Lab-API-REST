<?php
define('JWT_SECRET_KEY', 'Abadia2026_JWT_Secreto_Laboratorio_Software7');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'laboratorio_jwt');