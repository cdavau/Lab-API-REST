<?php
namespace Abadia\CrudApi;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class AuthService {

    private $secret;

    public function __construct() {
        $this->secret = JWT_SECRET_KEY;
    }

    // Genera un token JWT
    public function generarToken($username) {
        $payload = [
            'iat'  => time(),
            'exp'  => time() + 3600, 
            'user' => $username
        ];
        return JWT::encode($payload, $this->secret, 'HS256');
    }

    // Valida el token JWT del header
    public function validarToken() {
        $headers = getallheaders();
        if (!isset($headers['Authorization'])) {
            http_response_code(401);
            echo json_encode(['error' => 'Token no proporcionado']);
            exit();
        }

        $token = str_replace('Bearer ', '', $headers['Authorization']);

        try {
            $decoded = JWT::decode($token, new Key($this->secret, 'HS256'));
            return $decoded;
        } catch (\Exception $e) {
            http_response_code(401);
            echo json_encode(['error' => 'Token inválido: ' . $e->getMessage()]);
            exit();
        }
    }
}